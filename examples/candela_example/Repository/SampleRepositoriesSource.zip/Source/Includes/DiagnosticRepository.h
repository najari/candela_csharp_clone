/* ---------------------------------------------------------------------------
  File: DiagnosticRepository.h

  This header file describes the C-API interface the repository plugin has
  to provide. Please do not change this file because this would cause 
  interface compatibility problems of your plugin when called by CANdelaStudio.
------------------------------------------------------------------------------ */

#ifndef DIAGNOSTICREPOSITORY_H
#define DIAGNOSTICREPOSITORY_H

#ifdef DIAGNOSTIC_REPOSITORY_EXPORTS
#define DIAGNOSTIC_REPOSITORY_API __declspec(dllexport)
#else
#define DIAGNOSTIC_REPOSITORY_API __declspec(dllimport)
#endif

#define DIAGNOSTIC_REPOSITORY_VERSION 1
#define MAX_NAME_LEN 256
#define MAX_SUMMARY_LEN 4096
#define MAX_CONFIG_LEN 16384

extern "C"
{
  /* Return codes of repository functions */
  typedef enum {  repositoryResult_success,                // Repository operation successful.
                  repositoryResult_repositoryNotAvailable, // Failed. Repository not available (e.g. fileIO, network problem).
                  repositoryResult_bufferTooSmall,         // Failed. Given buffer is too small (try with bigger one).
                  repositoryResult_functionNotSupported,   // Failed. The requested function is not supported by this repository.
                  repositoryResult_illegalParameter,       // Failed. Given parameter is not valid or out of range.
                  repositoryResult_unknownError            // Failed. Unspecified error occurred.
               } RepositoryResult;

  /* Structure for one DID summary element provided by function GetMatchingDIDs() */
  typedef struct DidSummaryTag
  {
    unsigned long id;                     // Id of the DID
	  wchar_t uid[MAX_NAME_LEN];	          // Unique Identifier of the DID
	  wchar_t name[MAX_NAME_LEN];           // Name of the DID
	  wchar_t summary[MAX_SUMMARY_LEN];     // Summary of the DID content
  } DidSummary;

  /* Structure for one DTC summary element provided by function GetMatchingDTCs() */
  typedef struct DtcSummaryTag
  {
    unsigned long code;                   // DTC code
    wchar_t uid[MAX_NAME_LEN];	          // Unique Identifier of the DTC
    wchar_t text[MAX_NAME_LEN];           // Text of the DTC
    wchar_t summary[MAX_SUMMARY_LEN];     // Summary of the DTC content
  } DtcSummary;

  /* This function returns the name of the repository, the length of the name is 
     limited to MAX_NAME_LEN */
  DIAGNOSTIC_REPOSITORY_API RepositoryResult GetRepositoryName(wchar_t out_name[MAX_NAME_LEN]);

  /* This function returns the name of the vendor, the length of the name is 
     limited to MAX_NAME_LEN */
  DIAGNOSTIC_REPOSITORY_API RepositoryResult GetRepositoryVendor(wchar_t out_vendor[MAX_NAME_LEN]);

  /* This function returns the version of the repository API and should always return the
     constant DIAGNOSTIC_REPOSITORY_VERSION */
  DIAGNOSTIC_REPOSITORY_API unsigned int GetRepositoryAPIVersion();

  /* This function is called by CANdelaStudio after loading the repository plug in and provides plugin 
     configuration information if stored in the CANdelaStudio.ini file otherwise an empty string. 
     The plug in may use the config information for e.g. server or file selection.
     Read documentation to learn how to add your configuration information in the CANdelaStudio.ini file */
  DIAGNOSTIC_REPOSITORY_API RepositoryResult SetRepositoryConfig(wchar_t in_config[MAX_CONFIG_LEN]);

  /* This function returns the summary list of DIDs that is used by CANdelaStudio to fill the DID selection
     dialog. CANdelaStudio provides a full text search pattern that has to be evaluated by the plugin.
     The plugin provides a list of all matching DIDs. 
     
     Input param in_searchPattern:
     only DIDs that match the given search pattern in the DIDnr, name or summary shall be returned by the plugin

     Output param out_pDids: 
     CANdelaStudio provides an array of DidSummaryTag struct elements to the plugin. The plugin writes the values 
     of the matching DID elements to this struct elements. Allocation is done by CANdelaStudio, not by the plugin!

     Input/output param inout_pNumOfDids:
     When called by CANdelaStudio, the number of allocated DidSummaryTag structs in the array out_pDids is provided.
     If the number of provided elements is to small (number of matching DIDs is higher), the plugin provides the 
     number of necessary elements to CANdelaStudio and returns the function with the error code repositoryResult_bufferTooSmall.
     CANdelaStudio will repeat the call with the requested size of elements.
     If the number of provided elements is sufficient, the plugin provides the number of elements written to the out_pDids array.  */
  DIAGNOSTIC_REPOSITORY_API RepositoryResult GetMatchingDIDs(wchar_t const * in_searchPattern, struct DidSummaryTag** out_pDids, unsigned int* inout_pNumOfDids);

  /* This function returns the ODX envelope for a concrete DID requested by CANdelaStudio. The plugin has to
     provide the envelope for the selected DID. 
     
     Input param in_uid: 
     Unique identifier of the DID provided by CANdelaStudio

     Output param out_envelope:
     CANdelaStudio provides a string to the plugin. The plugin writes the ODX envelope of the considered DID to this string. 
     Allocation is done by CANdelaStudio, not by the plugin!

     Input/output param inout_pEnvelopeLen:
     When called by CANdelaStudio, the number of allocated string elements of out_enveloope is provided.
     If the number of provided elements is to small (size of ODX envelope is higher), the plugin provides the 
     number of necessary elements to CANdelaStudio and returns the function with the error code repositoryResult_bufferTooSmall.
     CANdelaStudio will repeat the call with the requested size of elements.
     If the number of provided elements is sufficient, the plugin provides the number of elements written to the out_envelope string.  */
  DIAGNOSTIC_REPOSITORY_API RepositoryResult ImportDID(wchar_t const * in_uid, wchar_t* out_envelope, unsigned int* inout_pEnvelopeLen);

  /* This function returns the summary list of DTCs that is used by CANdelaStudio to fill the DTC selection
  dialog. CANdelaStudio provides a full text search pattern that has to be evaluated by the plugin.
  The plugin provides a list of all matching DTCs.

  Input param in_searchPattern:
  only DTCs that match the given search pattern in the code, text or summary shall be returned by the plugin

  Output param out_pDtcs:
  CANdelaStudio provides an array of DtcSummaryTag struct elements to the plugin. The plugin writes the values
  of the matching DID elements to this struct elements. Allocation is done by CANdelaStudio, not by the plugin!

  Input/output param inout_pNumOfDtcs:
  When called by CANdelaStudio, the number of allocated DtcSummaryTag structs in the array out_pDtcs is provided.
  If the number of provided elements is to small (number of matching DTCs is higher), the plugin provides the
  number of necessary elements to CANdelaStudio and returns the function with the error code repositoryResult_bufferTooSmall.
  CANdelaStudio will repeat the call with the requested size of elements.
  If the number of provided elements is sufficient, the plugin provides the number of elements written to the out_pDtcs array.  */
  DIAGNOSTIC_REPOSITORY_API RepositoryResult GetMatchingDTCs(wchar_t const * in_searchPattern, struct DtcSummaryTag** out_pDtcs, unsigned int* inout_pNumOfDtcs);

  /* This function returns the ODX envelope for a concrete DTC requested by CANdelaStudio. The plugin has to
  provide the envelope for the selected DTC.

  Input param in_uid:
  Unique identifier of the DTC provided by CANdelaStudio

  Output param out_envelope:
  CANdelaStudio provides a string to the plugin. The plugin writes the ODX envelope of the considered DTC to this string.
  Allocation is done by CANdelaStudio, not by the plugin!

  Input/output param inout_pEnvelopeLen:
  When called by CANdelaStudio, the number of allocated string elements of out_enveloope is provided.
  If the number of provided elements is to small (size of ODX envelope is higher), the plugin provides the
  number of necessary elements to CANdelaStudio and returns the function with the error code repositoryResult_bufferTooSmall.
  CANdelaStudio will repeat the call with the requested size of elements.
  If the number of provided elements is sufficient, the plugin provides the number of elements written to the out_envelope string.  */
  DIAGNOSTIC_REPOSITORY_API RepositoryResult ImportDTC(wchar_t const * in_uid, wchar_t* out_envelope, unsigned int* inout_pEnvelopeLen);

  /* This function is called by CANdelaStudio whenever the plugin is not longer required and can be used to release resources that are
     allocated within this plugin. */
  DIAGNOSTIC_REPOSITORY_API void ReleaseRepositoryPlugin();
}
#endif
