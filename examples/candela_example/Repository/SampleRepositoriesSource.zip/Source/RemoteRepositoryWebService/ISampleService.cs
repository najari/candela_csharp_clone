﻿/*-----------------------------------------------------------------------------
  File: ISampleService.cs
  -------------------------------------------------------------------------- */
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace RemoteRepositoryWebService
{
  [ServiceContract]
  /// Interface description of the web service
  public interface ISampleService
  {
    [OperationContract]
    List<ElementSummary> GetMatchingDIDs(string textSearchPattern);

    [OperationContract]
    ImportElement ImportDid(string didNr);
  }

  [DataContract]
  public class ElementSummary
  {
    string mId = "";
    string mName = "";
    string mSummary = "";

    [DataMember]
    public string ID
    {
      get { return mId; }
      set { mId = value; }
    }

    [DataMember]
    public string Name
    {
      get { return mName; }
      set { mName = value; }
    }

    [DataMember]
    public string Summary
    {
      get { return mSummary; }
      set { mSummary = value; }
    }
  }

  [DataContract]
  public class ImportElement
  {
    private string mEnvelope;

    [DataMember]
    public string Envelope
    {
      get { return mEnvelope; }
      set { mEnvelope = value; }
    }
  }
}
