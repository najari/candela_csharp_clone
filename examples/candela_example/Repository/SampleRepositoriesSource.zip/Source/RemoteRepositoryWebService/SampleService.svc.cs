﻿/*-----------------------------------------------------------------------------
  File: SampleService.svc.cs
  -------------------------------------------------------------------------- */

using System;
using System.Collections.Generic;
using System.IO;

namespace RemoteRepositoryWebService
{
  /// <summary>
  /// Implementation of a simple web service. The interface is defined in ISampleService
  /// </summary>
  public class SampleService : ISampleService
  {
    private List<string[]> csvList;
    private List<ElementSummary> matchingDids;

    /// <summary>
    /// Returns a list of DIDs that are available in the repository and that match the given search pattern
    /// </summary>
    /// <param name="textSearchPattern">String that limitates des result of DIDs</param>
    /// <returns></returns>
    public List<ElementSummary> GetMatchingDIDs(string textSearchPattern)
    {
      if (null == csvList || 0 == csvList.Count) csvList = ReadIdentifierFromFile();
      if (null == matchingDids || 0 == matchingDids.Count) matchingDids = new List<ElementSummary>();

      foreach (var entry in csvList)
      {
        if (string.IsNullOrEmpty(entry[0])) continue;
        ElementSummary element = new ElementSummary { ID = entry[0], Name = entry[1], Summary = entry[2] };
        if (element.ID.Contains(textSearchPattern) || element.Name.Contains(textSearchPattern) || element.Summary.Contains(textSearchPattern))
          matchingDids.Add(element);
        if (matchingDids.Count > 100) break;
      }

      return matchingDids;
    }

    /// <summary>
    /// Returns the ODX envelope for the given DID number
    /// </summary>
    /// <param name="didNr">Number of the DID to be imported</param>
    /// <returns></returns>
    public ImportElement ImportDid(string didNr)
    {
      if (null == csvList || 0 == csvList.Count) csvList = ReadIdentifierFromFile();
      ImportElement element = null;
      foreach (var entry in csvList)
      {
        if (entry[0] == didNr)
        {
          string odxFile = Path.Combine(Properties.Settings.Default.DataPath, entry[3]);
          string envelope = File.ReadAllText(odxFile);
          element = new ImportElement { Envelope = envelope};
          break;
        }
      }

      return element;
    }

    /// <summary>
    /// Reads a CSV file into a list of string arrays
    /// </summary>
    /// <returns>List of string arrays.Each string array represents a CSV line</returns>
    private List<string[]> ReadIdentifierFromFile()
    {
      string csvFilePath = Path.Combine(Properties.Settings.Default.DataPath, Properties.Settings.Default.CSVFileName);
      var list = new List<string[]>();
      try
      {
        var sr = new StreamReader(csvFilePath);

        while (!sr.EndOfStream)
        {
          string[] values = null;
          string strline = sr.ReadLine();
          if (null != strline) values = strline.Split(';');
          list.Add(values);
        }
        sr.Close();
      }
      catch (Exception)
      {
        // File operation error, add handling here        
        throw;
      }
      return list;
    }

  }
}
