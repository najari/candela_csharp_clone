/* ----------------------------------------------------------------------------------
  File: LocalRepository.cpp
  -------------------------------------------------------------------------------- */

#include <string>
#include <vector>
#include "DiagnosticRepository.h"
#include <WebServices.h>
#include "RemoteRepositoryWebService.xsd.h"
#include "ISampleService.xsd.h"
#include "ISampleService.wsdl.h"

using namespace std;

typedef vector<vector <wstring>> CsvArrayContainer;
wstring configurationString;

//Declare the handles needed for using WWSAPI
HRESULT hr = 0;
WS_ERROR* error = nullptr;
WS_HEAP* heap = nullptr;
WS_SERVICE_PROXY* serviceProxy = nullptr;

// Forward declaration of local functions
RepositoryResult CheckBuffer(wchar_t const * buffer,  unsigned int bufLen, unsigned int requiredLen);
RepositoryResult OpenConnection();
void CloseConnection();

// Implementation of Plugin Functions

DIAGNOSTIC_REPOSITORY_API RepositoryResult GetRepositoryName(wchar_t out_name[MAX_NAME_LEN])
{
  // Return the name of your plugin
  wchar_t* str = L"Vector Sample Remote Webservice Repository";
  wcsncpy_s(out_name, MAX_NAME_LEN, str, _TRUNCATE);
  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult GetRepositoryVendor(wchar_t out_vendor[MAX_NAME_LEN])
{
  // Return the name of your organization
  wchar_t* str = L"Vector";
  wcsncpy_s(out_vendor, MAX_NAME_LEN, str, _TRUNCATE);
  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API unsigned int GetRepositoryAPIVersion()
{
  // Return always this constant value
  return DIAGNOSTIC_REPOSITORY_VERSION;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult SetRepositoryConfig(wchar_t in_config[MAX_CONFIG_LEN])
{
  // Store and use the configuration string if necessary
  configurationString = in_config;
  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult GetMatchingDIDs(wchar_t const * in_searchPattern, DidSummaryTag** out_pDids, unsigned int* inout_pNumOfDids)
{
  // This sample implementation queries a web service for all available DIDs. In your plugin the list of 
  // available DIDs may be stored in a data base or any other data source.
  // All  elements that match the given search pattern shall be returned.
  unsigned int givenBufferSize = *inout_pNumOfDids;

  // Open connection to the web server
  RepositoryResult rc = OpenConnection();
  if (repositoryResult_success != rc) return rc;

  // Build result structure
  ArrayOfElementSummary result;

  // Call web service
  wchar_t searchPatternBuf[MAX_PATH];
  wcsncpy_s(searchPatternBuf, MAX_PATH, in_searchPattern, _TRUNCATE);  
  hr = BasicHttpBinding_ISampleService_GetMatchingDIDs(
    serviceProxy, searchPatternBuf, &result.ElementSummaryCount, &result.ElementSummary,
    heap, nullptr, 0, nullptr, error);
  if (FAILED(hr))
  {
    // Failed to call operation on the service
    CloseConnection();
    return repositoryResult_repositoryNotAvailable;
  }

  // Put results into the output buffer
  DidSummaryTag* pDids = *out_pDids;
  unsigned int bufferIndex=0;
  for (unsigned int i = 0; i < result.ElementSummaryCount; ++i)
  { 
    wchar_t const * name = result.ElementSummary[i]->Name;
    wchar_t const * summary = result.ElementSummary[i]->Summary;
    wchar_t const * uid = result.ElementSummary[i]->ID;
    
    // check if the current entry matches the search pattern
    if (nullptr != wcsstr(name, in_searchPattern) ||
        nullptr != wcsstr(summary, in_searchPattern) ||
        nullptr != wcsstr(uid, in_searchPattern))
    {
      if (bufferIndex < givenBufferSize)
      {
        wcscpy_s(pDids[bufferIndex].name, name);
        wcscpy_s(pDids[bufferIndex].summary, summary);
        wcscpy_s(pDids[bufferIndex].uid, uid);
        std::wstring s = uid;
        pDids[bufferIndex].id = std::stoul(s, nullptr, 16);
      }
      ++bufferIndex;
    }
  }
  *inout_pNumOfDids = bufferIndex;
  CloseConnection();
  return bufferIndex >= givenBufferSize ? repositoryResult_bufferTooSmall : repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult ImportDID(wchar_t const * in_uid, wchar_t* out_envelope, unsigned int* inout_pEnvelopeLen)
{
  // This sample implementation provides an ODX envelope for a given data identifier.
  // It queries a web service for the requested ODX envelope. In your plugin, the envelope may be stored in a data base
  // or may be created on demand here.

  // Open connection to the web server
  RepositoryResult rc = OpenConnection();
  if (repositoryResult_success != rc) return rc;

  // Build result structure
  ImportElement result;
  ImportElement *pResult = &result;
  // Call web service
  wchar_t uidBuf[MAX_PATH];
  wcsncpy_s(uidBuf, MAX_PATH, in_uid, _TRUNCATE);
  hr = BasicHttpBinding_ISampleService_ImportDid(
    serviceProxy, uidBuf, &pResult,
    heap, nullptr, 0, nullptr, error);
  if (FAILED(hr))
  {
    // Failed to call operation on the service
    CloseConnection();
    return repositoryResult_repositoryNotAvailable;
  }
  std::wstring envelope = pResult->Envelope;
  auto requiredLen = envelope.length();

  // Check buffer length and return buffer
  rc = CheckBuffer(out_envelope, *inout_pEnvelopeLen, (unsigned int)requiredLen);
  if (repositoryResult_success != rc)
  {
    *inout_pEnvelopeLen = (unsigned int)requiredLen;
    CloseConnection();
    return rc;
  }

  wcsncpy_s(out_envelope, *inout_pEnvelopeLen, envelope.c_str(), requiredLen);
  CloseConnection();
  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult GetMatchingDTCs(wchar_t const * /*in_searchPattern*/, DidSummaryTag** /*out_pDids*/, unsigned int* /*inout_pNumOfDids*/)
{
  // This sample implementation does not support DTCs (see LocalRepository sample)
  return repositoryResult_functionNotSupported;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult ImportDTC(wchar_t const * /*in_uid*/, wchar_t* /*out_envelope*/, unsigned int* /*inout_pEnvelopeLen*/)
{
  // This sample implementation does not support DTCs (see LocalRepository sample)
  return repositoryResult_functionNotSupported;
}

// Checks for correct buffer length
RepositoryResult CheckBuffer(wchar_t const * buffer,  unsigned int bufLen, unsigned int requiredLen)
{
  if (nullptr == buffer || 0 == bufLen) return repositoryResult_illegalParameter;
  if(requiredLen >= bufLen) return repositoryResult_bufferTooSmall;
  return repositoryResult_success;
}

// Helper that opens a connection to a web service
RepositoryResult OpenConnection()
{
  hr = ERROR_SUCCESS;
  size_t const maxHeapSize = 1000000;
  WS_ENDPOINT_ADDRESS address = {};
  wstring serviceURL = configurationString.empty() ? L"http://localhost:8080/SampleService.svc" : configurationString;
  WS_STRING url = {(ULONG)serviceURL.size(), const_cast<wchar_t*>(serviceURL.c_str())};
  address.url = url;

  hr = WsCreateError(nullptr,  0,  &error);
  if (FAILED(hr))
  {
    // Failed to create Error object
    return repositoryResult_unknownError;
  }

  hr = WsCreateHeap(maxHeapSize, 0, nullptr, 0, &heap, error); 
  if (FAILED(hr))
  {
    // Failed to alloc heap
    return repositoryResult_unknownError;
  }

  // Create template data with binding information
  WS_HTTP_BINDING_TEMPLATE templateValue = {};
  ULONG maxMessageSize = UINT_MAX;
  WS_CHANNEL_PROPERTY channelProperty;
  channelProperty.id = WS_CHANNEL_PROPERTY_MAX_BUFFERED_MESSAGE_SIZE;
  channelProperty.value = &maxMessageSize;
  channelProperty.valueSize = sizeof(maxMessageSize);

  // Create Service Proxy
  WS_CHANNEL_PROPERTIES channelProperties;
  channelProperties.properties = &channelProperty;
  channelProperties.propertyCount = 1;
  templateValue.channelProperties = channelProperties;
  hr = BasicHttpBinding_ISampleService_CreateServiceProxy(&templateValue, nullptr, 0, &serviceProxy, error);
  if (FAILED(hr)) 
  {
    // Failed to create Service Proxy
    CloseConnection();
    return repositoryResult_repositoryNotAvailable;
  }

  // Open Connection
  hr = WsOpenServiceProxy(serviceProxy, &address, nullptr, error);
  if (FAILED(hr))
  {
    // Failed to open Service Proxy
    CloseConnection();
    return repositoryResult_repositoryNotAvailable;
  }

  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API void ReleaseRepositoryPlugin()
{
  // nothing to do for this plugin
}

// Helper that closes the connection to the web service and does cleanup
void CloseConnection()
{
  if (nullptr != serviceProxy)
  {
    WsCloseServiceProxy(serviceProxy, nullptr,  error);
    WsFreeServiceProxy(serviceProxy);
    serviceProxy = nullptr;
  }
  if (nullptr != heap)
  {
    WsFreeHeap(heap);
    heap = nullptr;
  }
  if (nullptr != error)
  {
    WsFreeError(error);
    error = nullptr;
  }
}
