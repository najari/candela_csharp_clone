@ECHO OFF
SET SVC_UTIL_PATH="C:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\Bin\svcutil.exe"
SET WS_UTIL_PATH="C:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\Bin\wsutil.exe"
SET SERVICE_URL=http://localhost:55451/SampleService.svc
ECHO -----------------------------------------------------------------------------------------------------------
ECHO Reading Meta-Data from the service URL...
ECHO -----------------------------------------------------------------------------------------------------------
%SVC_UTIL_PATH% /t:metadata %SERVICE_URL%?wsdl
ECHO -----------------------------------------------------------------------------------------------------------
ECHO Rename generated files
ECHO -----------------------------------------------------------------------------------------------------------
rename tempuri.org.xsd ISampleService.xsd
rename tempuri.org.wsdl ISampleService.wsdl
ECHO -----------------------------------------------------------------------------------------------------------
ECHO Generate web service stubs for C
ECHO -----------------------------------------------------------------------------------------------------------
%WS_UTIL_PATH% ISampleService.wsdl schemas.microsoft.com.2003.10.Serialization.xsd ISampleService.xsd RemoteRepositoryWebService.xsd

pause