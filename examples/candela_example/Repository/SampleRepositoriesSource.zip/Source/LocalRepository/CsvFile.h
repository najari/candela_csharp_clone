/* ------------------------------------------------------------------------------------
  File: CsvFile.h
  ---------------------------------------------------------------------------------- */

#pragma once

#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <sstream>
#include <memory>

namespace CsvAccess
{
  typedef std::vector<std::wstring> CsvLine;
  typedef std::unique_ptr<CsvLine> CsvLinePtr;
  typedef std::vector<CsvLinePtr> CsvArrayContainer;
  
  /* This class reads a CSV file into a std::vector. Each row is represented by a vector of strings.
     Each string represents a column value of the CSV table. */
  class CsvFile  
  {
  public:
    // Constructs a CsvArray object and reads the CSV file from the given file name
    CsvFile(wchar_t const * filename);
    // Returns the CSV array. All lines of the CSV file are stored in a STL vector object.
    // Each line is represented by a STL vector of strings.
    CsvArrayContainer const & GetCsvArray() const;

  private:
    // exclude use of (default) copy-ctor and assignment operator
    CsvFile(CsvFile const &);
    CsvFile& operator=(CsvFile const &);
    // Loads the given CSV file into the CSV array. Called by the constructor of class.
    bool Load(wchar_t const * filename ) ;
    // Helper that separates a CSV column from a stream
    std::wstring CsvFile::GetCsvColumn(std::wistringstream & in);
    CsvArrayContainer csvArray;
    std::wstring fileName;
  };
}  // namespace  CsvAccess