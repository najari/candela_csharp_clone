/* ---------------------------------------------------------------------------------
  File: CsvFile.cpp
--------------------------------------------------------------------------------- */

#include "CsvFile.h"

using namespace CsvAccess;
using namespace std;

CsvFile::CsvFile(wchar_t const * in_FileName) : fileName(in_FileName)
{
  Load(fileName.c_str());
}

CsvArrayContainer const & CsvFile::GetCsvArray() const
{
  return csvArray;
}

bool CsvFile::Load(wchar_t const * fullpath ) 
{
  // Opens and runs through the CSV file and builds up the CSV array
  wstring s;
  wifstream f(fullpath);
  if (!f.bad())
  {
    while (getline(f, s))
    {
      wistringstream iss(s);
      unique_ptr<CsvLine> line(new CsvLine());
      for (std::wstring col; iss;)
      {
        col = GetCsvColumn(iss);
        line->push_back(col);
      }
      if (!f && !f.eof())
      {
        return false;
      }
      csvArray.push_back(std::move(line));
    }
  }
  return f.good();
}

wstring CsvFile::GetCsvColumn(wistringstream & in)
{
  // Helper that separates the columns of a CSV file line.
  // Minds quotations.
  // Supported separator is ';'
  wstring col;
  unsigned quotes = 0;
  wchar_t prevCh = 0;
  bool endOfCol = false;
  for (wchar_t ch; !endOfCol && (ch = in.get()) != WEOF;)
  {
    switch (ch) 
    {
      case '"':
        ++quotes;
        break;
      case ';':
        if (quotes == 0 || (prevCh == '"' && (quotes & 1) == 0)) 
        {
          endOfCol = true;
        }
        break;
      default:;
    }
    if (!endOfCol) col += prevCh = ch;
  }
  return col;
}
