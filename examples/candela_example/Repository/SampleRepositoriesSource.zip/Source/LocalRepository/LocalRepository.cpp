/* ---------------------------------------------------------------------------------
  File: LocalRepository.cpp
  ------------------------------------------------------------------------------- */

#include <string.h>
#include <codecvt>
#include <algorithm>
#include "Shlwapi.h"
#include "DiagnosticRepository.h"
#include "CsvFile.h"

using namespace CsvAccess;
using namespace std;

// Definition of the CSV columns
enum CsvColumnNames
{
  CsvUidColumn = 0,
  CsvNameColumn = 1,
  CsvSummaryColumn = 2,
  CsvEnvelopeColumn = 3
};
unsigned int const CsvColumnMaxCount = 4; 

unique_ptr<CsvFile> pCsvFileDID;
unique_ptr<CsvFile> pCsvFileDTC;
wstring configurationString;

// Forward declaration of local functions
RepositoryResult CheckBuffer(wchar_t const * buffer,  unsigned int bufLen, unsigned int requiredLen);
wstring GetPathToFile(wchar_t const * file);
wstring GetPathToODXFile(wchar_t const * basePath, wchar_t const * filename);
wstring LoadFileToString(wchar_t const * fullpath );

// Implementation of Plugin Functions

DIAGNOSTIC_REPOSITORY_API RepositoryResult GetRepositoryName(wchar_t out_name[MAX_NAME_LEN])
{
  // Return the name of your plugin
  wchar_t const * str = L"Vector Sample Local CSV Repository";
  wcsncpy_s(out_name, MAX_NAME_LEN, str, _TRUNCATE);
  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult GetRepositoryVendor(wchar_t out_vendor[MAX_NAME_LEN])
{
  // Return the name of your organization
  wchar_t const * str = L"Vector";
  wcsncpy_s(out_vendor, MAX_NAME_LEN, str, _TRUNCATE);
  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API unsigned int GetRepositoryAPIVersion()
{
  // Return always this constant value
  return DIAGNOSTIC_REPOSITORY_VERSION;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult SetRepositoryConfig(wchar_t in_config[MAX_CONFIG_LEN])
{
  // Store and use the configuration string if necessary
  configurationString = in_config;
  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult GetMatchingDIDs(wchar_t const * in_searchPattern, DidSummaryTag** out_pDids, unsigned int* inout_pNumOfDids)
{
  // This sample implementation reads a CSV file to get all available DIDs. In your plugin the list of 
  // available DIDs may be stored in a data base or any other data source.
  // All  elements that match the given search pattern shall be returned.

  unsigned int givenBufferSize = *inout_pNumOfDids;

  // Load and parse CSV file if not already done
  if (nullptr == pCsvFileDID)
  {
    try
    {
      wstring csvFile = configurationString.empty() ? GetPathToFile(L"Plugins\\RepositorySampleDID.csv") : configurationString;
      pCsvFileDID.reset(new CsvFile(csvFile.c_str()));
    }
    catch (std::bad_alloc const & /*ex*/)
    {
      return repositoryResult_unknownError;    	
    }
    catch (std::exception const & /*ex*/)
    {
      return repositoryResult_repositoryNotAvailable;    	
    }
  }

  // Put search results into the output buffer
  DidSummaryTag* pDids = *out_pDids;
  unsigned int bufferIndex=0;

  for(auto it = pCsvFileDID->GetCsvArray().begin(); it != pCsvFileDID->GetCsvArray().end() ; ++it)
  {
    if ((*it)->size() == CsvColumnMaxCount)
    {
      wchar_t const * csvname = (*it)->at(CsvNameColumn).c_str();
      wchar_t const * csvsummary = (*it)->at(CsvSummaryColumn).c_str();
      wchar_t const * csvuid = (*it)->at(CsvUidColumn).c_str();

      // check if the current entry matches the search pattern
      if (nullptr != wcsstr(csvname, in_searchPattern) ||
          nullptr != wcsstr(csvsummary, in_searchPattern) ||
          nullptr != wcsstr(csvuid, in_searchPattern))
      {
        // If the target buffer is big enough, copy the attributes from
        // the CSV array to the target DID list
        if (bufferIndex < givenBufferSize)
        {
          wcsncpy_s(pDids[bufferIndex].name, MAX_NAME_LEN, csvname, _TRUNCATE);
          wcsncpy_s(pDids[bufferIndex].summary, MAX_SUMMARY_LEN, csvsummary, _TRUNCATE);
          wcsncpy_s(pDids[bufferIndex].uid, MAX_NAME_LEN, csvuid, _TRUNCATE);
          pDids[bufferIndex].id = std::stoul((*it)->at(CsvUidColumn).c_str(), nullptr, 16);
        }
        ++bufferIndex;
      }
    }
  }
  // set the count of used buffer elements
  *inout_pNumOfDids = bufferIndex;
  return bufferIndex >= givenBufferSize ? repositoryResult_bufferTooSmall : repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult ImportDID(wchar_t const * in_uid, wchar_t* out_envelope, unsigned int* inout_pEnvelopeLen)
{
  // This sample implementation provides an ODX envelope for a given data identifier.
  // It reads the envelope from a ODX file. In your plugin the envelope may be stored in a data base
  // or may be created on demand here.

  // Search for the requested DID
  auto rowIter = find_if (pCsvFileDID->GetCsvArray().begin(), pCsvFileDID->GetCsvArray().end(), [&in_uid] (CsvLinePtr const & pLine) 
  {
    return in_uid == pLine->at(0);
  }
  );

  // ... if not found
  if (rowIter == pCsvFileDID->GetCsvArray().end())
  {
    return repositoryResult_illegalParameter;
  }

  // compute the path to the ODX envelope file
  wstring csvEnvelopeFile = (*rowIter)->at(CsvEnvelopeColumn);
  if (configurationString.empty())
  {
    csvEnvelopeFile = L"Plugins\\" + csvEnvelopeFile;
    csvEnvelopeFile = GetPathToFile(csvEnvelopeFile.c_str());
  }
  else 
  {
    csvEnvelopeFile = GetPathToODXFile(configurationString.c_str(), csvEnvelopeFile.c_str());
  }

  // load file into string
  wstring envelope = LoadFileToString(csvEnvelopeFile.c_str());

  // Check buffer length and return buffer
  auto requiredLen = envelope.length();
  RepositoryResult rc = CheckBuffer(out_envelope, *inout_pEnvelopeLen, (unsigned int)requiredLen);
  if (repositoryResult_success != rc)
  {
    *inout_pEnvelopeLen = (unsigned int)requiredLen;
    return rc;
  }
  wcsncpy_s(out_envelope, *inout_pEnvelopeLen, envelope.c_str(), requiredLen);
  return repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult GetMatchingDTCs(wchar_t const * in_searchPattern, DtcSummaryTag** out_pDtcs, unsigned int* inout_pNumOfDtcs)
{
  // This sample implementation reads a CSV file to get all available DTCs. In your plugin the list of 
  // available DTCs may be stored in a data base or any other data source.
  // All  elements that match the given search pattern shall be returned.

  unsigned int givenBufferSize = *inout_pNumOfDtcs;

  // Load and parse CSV file if not already done
  if (nullptr == pCsvFileDTC)
  {
    try
    {
      wstring csvFile = configurationString.empty() ? GetPathToFile(L"Plugins\\RepositorySampleDTC.csv") : configurationString;
      pCsvFileDTC.reset(new CsvFile(csvFile.c_str()));
    }
    catch (std::bad_alloc const & /*ex*/)
    {
      return repositoryResult_unknownError;
    }
    catch (std::exception const & /*ex*/)
    {
      return repositoryResult_repositoryNotAvailable;
    }
  }

  // Put search results into the output buffer
  DtcSummaryTag* pDtcs = *out_pDtcs;
  unsigned int bufferIndex = 0;

  for (auto it = pCsvFileDTC->GetCsvArray().begin(); it != pCsvFileDTC->GetCsvArray().end(); ++it)
  {
    if ((*it)->size() == CsvColumnMaxCount)
    {
      wchar_t const * csvname = (*it)->at(CsvNameColumn).c_str();
      wchar_t const * csvsummary = (*it)->at(CsvSummaryColumn).c_str();
      wchar_t const * csvuid = (*it)->at(CsvUidColumn).c_str();

      // check if the current entry matches the search pattern
      if (nullptr != wcsstr(csvname, in_searchPattern) ||
        nullptr != wcsstr(csvsummary, in_searchPattern) ||
        nullptr != wcsstr(csvuid, in_searchPattern))
      {
        // If the target buffer is big enough, copy the attributes from
        // the CSV array to the target DTC list
        if (bufferIndex < givenBufferSize)
        {
          wcsncpy_s(pDtcs[bufferIndex].text, MAX_NAME_LEN, csvname, _TRUNCATE);
          wcsncpy_s(pDtcs[bufferIndex].summary, MAX_SUMMARY_LEN, csvsummary, _TRUNCATE);
          wcsncpy_s(pDtcs[bufferIndex].uid, MAX_NAME_LEN, csvuid, _TRUNCATE);
          pDtcs[bufferIndex].code = std::stoul((*it)->at(CsvUidColumn).c_str(), nullptr, 16);
        }
        ++bufferIndex;
      }
    }
  }
  // set the count of used buffer elements
  *inout_pNumOfDtcs = bufferIndex;
  return bufferIndex >= givenBufferSize ? repositoryResult_bufferTooSmall : repositoryResult_success;
}

DIAGNOSTIC_REPOSITORY_API RepositoryResult ImportDTC(wchar_t const * in_uid, wchar_t* out_envelope, unsigned int* inout_pEnvelopeLen)
{
  // This sample implementation provides an ODX envelope for a given DTC.
  // It reads the envelope from a ODX file. In your plugin the envelope may be stored in a data base
  // or may be created on demand here.

  // Search for the requested DTC
  auto rowIter = find_if(pCsvFileDTC->GetCsvArray().begin(), pCsvFileDTC->GetCsvArray().end(), [&in_uid](CsvLinePtr const & pLine)
  {
    return in_uid == pLine->at(0);
  }
  );

  // ... if not found
  if (rowIter == pCsvFileDTC->GetCsvArray().end())
  {
    return repositoryResult_illegalParameter;
  }

  // compute the path to the ODX envelope file
  wstring csvEnvelopeFile = (*rowIter)->at(CsvEnvelopeColumn);
  if (configurationString.empty())
  {
    csvEnvelopeFile = L"Plugins\\" + csvEnvelopeFile;
    csvEnvelopeFile = GetPathToFile(csvEnvelopeFile.c_str());
  }
  else
  {
    csvEnvelopeFile = GetPathToODXFile(configurationString.c_str(), csvEnvelopeFile.c_str());
  }

  // load file into string
  wstring envelope = LoadFileToString(csvEnvelopeFile.c_str());

  // Check buffer length and return buffer
  auto requiredLen = envelope.length();
  RepositoryResult rc = CheckBuffer(out_envelope, *inout_pEnvelopeLen, (unsigned int)requiredLen);
  if (repositoryResult_success != rc)
  {
    *inout_pEnvelopeLen = (unsigned int)requiredLen;
    return rc;
  }
  wcsncpy_s(out_envelope, *inout_pEnvelopeLen, envelope.c_str(), requiredLen);
  return repositoryResult_success;
}



DIAGNOSTIC_REPOSITORY_API void ReleaseRepositoryPlugin()
{
  // nothing to do for this plugin
}

// Checks for correct buffer length
RepositoryResult CheckBuffer(wchar_t const * buffer,  unsigned int bufLen, unsigned int requiredLen)
{
  if (nullptr == buffer || 0 == bufLen) return repositoryResult_illegalParameter;
  if(requiredLen >= bufLen) return repositoryResult_bufferTooSmall;
  return repositoryResult_success;
}

// Helper that determines the path to sample files
wstring GetPathToFile(wchar_t const * file)
{
  wchar_t* path = nullptr;
  _get_wpgmptr(&path);
  wstring newFile = path;
  wstring::size_type pos = newFile.find(L"CANdelaStudio.exe");
  newFile.replace(pos, wstring::npos,  file);
  return wstring(newFile);
}

// Computes the path to an ODX file
wstring GetPathToODXFile(wchar_t const * basePath, wchar_t const * filename)
{
  wchar_t result[MAX_PATH];
  wchar_t pathBuf[MAX_PATH];
  wcsncpy_s(pathBuf, MAX_PATH, basePath, _TRUNCATE);
  PathRemoveFileSpecW(pathBuf);
  PathCombineW(result, pathBuf, filename);
  return wstring(result);
}

// Load an ODX file to a string
wstring LoadFileToString(wchar_t const * fullpath) 
{
    std::wifstream wif(fullpath);
    wif.imbue(std::locale(std::locale::empty(), new std::codecvt_utf8<wchar_t>));
    std::wstringstream wss;
    wss << wif.rdbuf();
    return wss.str();
}
